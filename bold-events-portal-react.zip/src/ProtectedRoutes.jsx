import { Navigate, Outlet } from "react-router-dom";

export const ProtectedRoute = ({ isAuthenticated, children, returnUrl }) => {
  if (!isAuthenticated) {
    return <Navigate to={`/login?returnurl=${returnUrl}`} />;
  }
  return children ? children : <Outlet />;
};
