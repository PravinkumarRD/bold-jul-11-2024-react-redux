import axios from "../../Shared/AxiosInterceptor/BoldAxios";

async function getAllEvents() {
  try {
    return (
      await axios.get(`/events`)
    ).data;
  } catch (error) {
    throw error;
  }
}
async function getEventDetails(eventId) {
  try {
    return (await axios.get(`/events/${eventId}`)).data;
  } catch (error) {
    throw error;
  }
}

export { getAllEvents, getEventDetails };

/*
import { MOCK_DATA } from "../../mock-data";

function getAllEvents() {
  return MOCK_DATA.events;
}
function getEventDetails(eventId) {
  return MOCK_DATA.events.find((event) => event.eventId === eventId);
}
*/
