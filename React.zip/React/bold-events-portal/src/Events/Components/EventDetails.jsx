import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

import { getEventDetails } from "../Services/EventsService";

// const EventDetails = ({ eventId }) => {
const EventDetails = () => {
  const [event, setEvent] = useState(null);
  const params = useParams();
  let title = "Details Of - ";
  useEffect(() => {
    const eventId=params.id;
    (async () => {
      setEvent(await getEventDetails(Number.parseInt(eventId)));
    })();
  }, [params]);

  if (event) {
    return (
      <>
        <h1>{title + event.eventName}</h1>
        <table className="table table-hover table-striped">
          <tbody>
            <tr>
              <th>Event Id</th>
              <td>
                <span>{event.eventId}</span>
              </td>
            </tr>
            <tr>
              <th>Event Code</th>
              <td>
                <span>{event.eventCode}</span>
              </td>
            </tr>
            <tr>
              <th>Event Name</th>
              <td>
                <span>{event.eventName}</span>
              </td>
            </tr>
            <tr>
              <th>Description</th>
              <td>
                <span>{event.description}</span>
              </td>
            </tr>
            <tr>
              <th>Start Date</th>
              <td>
                <span>{event.startDate.toString()}</span>
              </td>
            </tr>
            <tr>
              <th>End Date</th>
              <td>
                <span>{event.endDate.toString()}</span>
              </td>
            </tr>
            <tr>
              <th>Fees</th>
              <td>
                <span>{event.fees}</span>
              </td>
            </tr>
            <tr>
              <th>Total Seats Filled</th>
              <td>
                <div className="progress" role="progressbar">
                  <div
                    className="progress-bar progress-bar-striped progress-bar-animated"
                    style={{ width: event.seatsFilled + "%" }}
                    title={event.seatsFilled + "%"}
                  >
                    {event.seatsFilled + "%"}
                  </div>
                </div>
              </td>
            </tr>
            <tr>
              <th>Logo</th>
              <td>
                <img src={'../'+event.logo} alt={event.eventName} />
              </td>
            </tr>
          </tbody>
        </table>
      </>
    );
  } else {
    return <h4>No Event Found!</h4>;
  }
};

export default EventDetails;
