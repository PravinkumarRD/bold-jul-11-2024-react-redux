import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";

import { getAllEvents } from "../Services/EventsService";
// import { EventDetails } from "./EventDetails";

const EventsList = () => {
  const [events, setEvents] = useState([]);
  // const [eventId, setEventId] = useState(0);
  useEffect(() => {
    (async () => {
      setEvents(await getAllEvents());
    })();
    return () => {};
  }, []);
  // const onEventSelection = function (eventId) {
  //   setEventId(eventId);
  //   console.log(eventId);
  // };
  if (events.length > 0) {
    return (
      <>
        <h1 className="display-1">Welcome To Bold Events List!</h1>
        <hr />
        <h6>Published by BOLD Hr Team!</h6>
        <table className="table table-hover table-striped">
          <thead>
            <tr>
              <th>Event Code</th>
              <th>Event Name</th>
              <th>Start Date</th>
              <th>Fees</th>
              <th>Show Details</th>
            </tr>
          </thead>
          <tbody>
            {events.map((event) => (
              <tr key={event.eventId}>
                <td>
                  <span>{event.eventCode}</span>
                </td>
                <td>
                  <span>{event.eventName}</span>
                </td>
                <td>
                  <span>{event.startDate.toString()}</span>
                </td>
                <td>
                  <span>{event.fees}</span>
                </td>
                <td>
                  {/* <button
                    className="btn btn-primary"
                    onClick={() => onEventSelection(event.eventId)}
                  >
                    Show Details
                  </button> */}
                  <NavLink
                    className="btn btn-primary"
                    to={"/events/" + event.eventId}
                  >
                    Show Details
                  </NavLink>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* {eventId > 0 ? <EventDetails eventId={eventId} /> : ""} */}
      </>
    );
  } else {
    return <h3>Sorry! We did't find any event! Please try after some time!</h3>;
  }
};
export default EventsList;

/*
//   const eventsStyles = {
//     textAlign: "right",
//     color: "blue",
//   };
      <h1 style={{ color: "red", textAlign: "center" }}>
        Welcome To Bold Events List!
      </h1>
      <h1 style={{...eventsStyles,textAlign:"center"}}>
        Welcome To Bold Events List!
      </h1>
      <hr />
      <h6 style={eventsStyles}>Published by BOLD Hr Team!</h6>
*/
