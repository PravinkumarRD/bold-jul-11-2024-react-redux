import { lazy, Suspense } from "react";
import { Routes, Route, useLocation } from "react-router-dom";

import { Navbar } from "./Navigation/Components/Navbar";
import { BoldHome } from "./Home/BoldHome";
import { Login } from "./Security/Components/Login";
import { ProtectedRoute } from "./ProtectedRoutes";

import { getTokenFromLocalStorage } from "./Shared/Utilities/localStorageUtility";
const EmployeesList = lazy(() =>
  import("./Employees/Components/EmployeesList")
);
const EventsList = lazy(() => import("./Events/Components/EventsList"));
const EventDetails = lazy(() => import("./Events/Components/EventDetails"));

export const MainLayout = () => {
  const location = useLocation();
  return (
    <>
      <Navbar />
      <Suspense
        fallback={
          <>
            <h1>Loading...</h1>
          </>
        }
      >
        <Routes>
          <Route path="/" element={<BoldHome />} />
          <Route path="/home" element={<BoldHome />} />
          <Route path="/employees" element={<EmployeesList />} />
          <Route
            element={
              <ProtectedRoute
                isAuthenticated={getTokenFromLocalStorage("token")}
                returnUrl={location.pathname}
              />
            }
          >
            <Route path="/events" element={<EventsList />} />
            <Route path="/events/:id" element={<EventDetails />} />
          </Route>

          <Route path="/login" element={<Login />} />
        </Routes>
      </Suspense>
    </>
  );
};
