import axios from "../../Shared/AxiosInterceptor/BoldAxios";

async function getAllEmployees() {
  try {
    return (await axios.get(`/employees`)).data;
  } catch (error) {
    throw error;
  }
}
async function getEmployeeDetails(employeeId) {
  try {
    return (await axios.get(`/employees/${employeeId}`)).data;
  } catch (error) {
    throw error;
  }
}

export { getAllEmployees, getEmployeeDetails };

/*
import { MOCK_DATA } from "../../mock-data";

function getAllEvents() {
  return MOCK_DATA.events;
}
function getEventDetails(eventId) {
  return MOCK_DATA.events.find((event) => event.eventId === eventId);
}
*/
