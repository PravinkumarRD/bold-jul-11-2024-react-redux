import React from "react";

const EmployeesList = () => {
  return (
    <>
      <h1>Welcome To Bold Employees List! India!</h1>
    </>
  );
};

export default EmployeesList;
