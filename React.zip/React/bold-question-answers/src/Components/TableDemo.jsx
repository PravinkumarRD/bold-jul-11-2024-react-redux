import { useRef, useState, useEffect } from "react";

export const TableDemo = () => {
  const [data, setData] = useState([]);
  const [selectedRow, setSelectedRow] = useState(null);
  const buttonRefs = useRef([]);

  useEffect(() => {
    setData([
      { id: 1, name: "Manish Sharma", age: 25 },
      { id: 2, name: "Ali Khan", age: 30 },
      { id: 3, name: "Alisha C.", age: 35 },
    ]);
  }, []);

  const handleRowSelect = (index) => {
    setSelectedRow(index);
  };

  const handleButtonClick = (text) => {
    console.log(`Button clicked: ${text}`);
  };

  return (
    <table className="table table-hover table-striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Age</th>
        </tr>
      </thead>
      <tbody>
        {data.map((row, index) => (
          <tr key={row.id} onClick={() => handleRowSelect(index)}>
            <td>
              {selectedRow === index ? (
                <button className="btn btn-success"
                  ref={(el) => (buttonRefs.current[index] = el)}
                  onClick={() => handleButtonClick(row.name)}
                >
                  {row.name}
                </button>
              ) : (
                row.name
              )}
            </td>
            <td>
              {selectedRow === index ? (
                <button className="btn btn-success"
                  ref={(el) => (buttonRefs.current[index] = el)}
                  onClick={() => handleButtonClick(row.age)}
                >
                  {row.age}
                </button>
              ) : (
                row.age
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};
