import "./App.css";
import { TableDemo } from "./Components/TableDemo";

function App() {
  return <>
    <TableDemo/>
  </>;
}

export default App;
