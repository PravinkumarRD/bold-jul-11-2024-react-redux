import { Navigate, Outlet } from "react-router-dom";

export const ProtectedRoute = ({ isAuthenticated, children, returnUrl }) => {
  if (!isAuthenticated) {
    return <Navigate to={`/signin?returnurl=${returnUrl}`} />;
  }
  return children ? children : <Outlet />;
};
