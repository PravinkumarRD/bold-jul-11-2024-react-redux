import { legacy_createStore, applyMiddleware, compose } from "redux";

import logger from "redux-logger";
import { thunk } from "redux-thunk";

import boldReducers from "../reducers/bold-reducer";

const middleware = [thunk, logger];

const InitialState = {};

const store = legacy_createStore(
  boldReducers,
  InitialState,
  compose(
    applyMiddleware(...middleware),
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
  )
);

export default store;
