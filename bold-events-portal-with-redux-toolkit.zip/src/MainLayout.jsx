import { lazy, Suspense } from "react";
import { Route, Routes, useLocation } from "react-router-dom";

import { getTokenFromLocalStorage } from "./Shared/Utilities/localStorageService";

import { Navbar } from "./Navigation/Components/Navbar";
import { BoldHome } from "./Home/BoldHome";
import { Login } from "./Security/Components/Login";
import { EventDetails } from "./Events/Components/EventDetails";
import { ProtectedRoute } from "./ProtectedRoute";
const EventsList = lazy(() => import("./Events/Components/EventsList"));
const EmployeesList = lazy(() =>
  import("./Employees/Components/Container/EmployeesList")
);

export const MainLayout = () => {
  const location = useLocation();
  return (
    <>
      <Navbar />
      <Suspense fallback={<h1>Loading...</h1>}>
        <Routes>
          <Route path="/" element={<BoldHome />} />
          <Route path="/home" element={<BoldHome />} />
          <Route path="/employees" element={<EmployeesList />} />
          <Route
            element={
              <ProtectedRoute
                isAuthenticated={getTokenFromLocalStorage("token")}
                returnUrl={location.pathname}
              />
            }
          >
            <Route path="/events" element={<EventsList />} />
            <Route path="/events/:id" element={<EventDetails />} />
          </Route>
          <Route path="/signin" element={<Login />} />
        </Routes>
      </Suspense>
    </>
  );
};
