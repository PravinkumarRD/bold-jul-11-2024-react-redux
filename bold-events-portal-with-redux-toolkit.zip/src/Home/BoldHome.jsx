import React from 'react'

export const BoldHome = () => {
  return (
    <div>
        <h1>Welcome To Bold Events Management Portal!</h1>
        <hr />
        <h6>Designed and Developed Bold! India Developers!</h6>
    </div>
  )
}
