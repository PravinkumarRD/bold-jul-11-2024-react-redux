import { BrowserRouter } from "react-router-dom";
import { MainLayout } from "./MainLayout";
import { Provider } from "react-redux";

import BoldStore from "./RtkStore/Store";

function App() {
  return (
    <Provider store={BoldStore}>
      <BrowserRouter>
        <MainLayout />
      </BrowserRouter>
    </Provider>
  );
}

export default App;
