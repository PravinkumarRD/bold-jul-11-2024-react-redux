import { useState, useEffect } from "react";

import { getEmployeeDetails } from "../../services/employees-service";

export const EmployeeDetails = ({ employeeId }) => {
  let title = "Details Of - ";

  let [employee, setEmployee] = useState(null);
  useEffect(() => {
    (async () => {
      setEmployee(await getEmployeeDetails(employeeId));
    })();
    return () => {
      //cleanup operations
    };
  }, [employeeId]);
  if (employee) {
    return (
      <div className="container">
        <h1>{title + employee.employeeName}</h1>
        <br />
        <table className="table table-hover table-striped">
          <tbody>
            <tr>
              <th>Employee Id</th>
              <td>
                <span>{employee.employeeId}</span>
              </td>
            </tr>
            <tr>
              <th>Employee Name</th>
              <td>
                <span>{employee.employeeName}</span>
              </td>
            </tr>
            <tr>
              <th>Address</th>
              <td>
                <span>{employee.address}</span>
              </td>
            </tr>
            <tr>
              <th>City</th>
              <td>
                <span>{employee.city}</span>
              </td>
            </tr>
            <tr>
              <th>Country</th>
              <td>
                <span>{employee.country}</span>
              </td>
            </tr>
            <tr>
              <th>Zipcode</th>
              <td>
                <span>{employee.zipcode}</span>
              </td>
            </tr>
            <tr>
              <th>Email Id</th>
              <td>
                <span>{employee.email}</span>
              </td>
            </tr>
            <tr>
              <th>Contact #</th>
              <td>
                <span>{employee.phone}</span>
              </td>
            </tr>
            <tr>
              <th>Skillsets</th>
              <td>
                <span>{employee.skillSets}</span>
              </td>
            </tr>
            <tr>
              <th>Avatar</th>
              <td>
                <img src={employee.avatar} alt={employee.employeeName} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  } else {
    return <h4>Loading...</h4>;
  }
};
