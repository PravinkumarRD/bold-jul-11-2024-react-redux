import React, { Component } from "react";
import { connect } from "react-redux";

import { fetchAllEmployees } from "../../../RtkStore/Slices/employeesSlice";

class EmployeesList extends Component {
  #title = "Welcome To BOLD Employees List!";
  #subTitle = "Core Development members of BOLD! India!";
  componentDidMount() {
    this.props.fetchAllEmployees();
  }
  // onEmployeeSelection = (employeeId) => {
  //   this.setState(
  //     {
  //       selectedEmployeeId: employeeId,
  //     },
  //     () => console.log(this.state.selectedEmployeeId)
  //   );
  // };
  render() {
    if (this.props.employees.length > 0) {
      return (
        <div>
          <h1>{this.#title}</h1>
          <hr />
          <h6>{this.#subTitle}</h6>
          <table className="table table-hover table-striped">
            <thead>
              <tr>
                <th>Employee Name</th>
                <th>City</th>
                <th>Email Id</th>
                <th>Contact #</th>
                <th>Show Details</th>
              </tr>
            </thead>
            <tbody>
              {this.props.employees.map((employee) => (
                <tr key={employee.employeeId}>
                  <td>
                    <span>{employee.employeeName}</span>
                  </td>
                  <td>
                    <span>{employee.city}</span>
                  </td>
                  <td>
                    <span>{employee.email}</span>
                  </td>
                  <td>
                    <span>{employee.phone}</span>
                  </td>
                  <td>
                    <button
                      className="btn btn-primary"
                      onClick={() =>
                        this.onEmployeeSelection(employee.employeeId)
                      }
                    >
                      Show Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {/* {(() => {
            if (this.state.selectedEmployeeId > 0) {
              return (
                <EmployeeDetails employeeId={this.state.selectedEmployeeId} />
              );
            }
          })()} */}
        </div>
      );
    } else {
      return <h4>No Data Found! Please try after some time!</h4>;
    }
  }
}

const mapStateToProps = (state) => ({
  employees: state.employeesReducer.employees,
});

export default connect(mapStateToProps, { fetchAllEmployees })(EmployeesList);
