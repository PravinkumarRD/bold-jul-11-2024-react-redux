import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchEvents } from "../../RtkStore/Slices/eventsSlice";
import { NavLink } from "react-router-dom";

import {
  dateFormatter,
  currencyFormatter,
} from "../../Shared/Utilities/Globalization";
// import { getAllEvents } from "../Services/EventsService";
// import { EventDetails } from "./EventDetails";

const EventsList = () => {
  let title = "Welcome To BOLD Events List!";
  let subTitle = "Published by BOLD Hr Team! India!";
  const dispatch = useDispatch();
  const events = useSelector((state) => state.eventsReducer.events);
  const status = useSelector((state) => state.eventsReducer.status);
  // const error = useSelector((state) => state.eventsReducer.error);

  useEffect(() => {
    if (status === 'idle') {
      dispatch(fetchEvents());
    }
  }, [status, dispatch]);

  // async function onEventSelection(eventId) {
  //   // setSelectedEvent(await getEventDetails(eventId));
  // }
  if (events && events.length > 0) {
    return (
      <div className="container">
        <h1>{title}</h1>
        <hr />
        <h6>{subTitle}</h6>
        <table className="table table-hover table-striped">
          <thead>
            <tr>
              <th>Event Code</th>
              <th>Event Name</th>
              <th>Start Date</th>
              <th>Fees</th>
              <th>Show Details</th>
            </tr>
          </thead>
          <tbody>
            {events.map((event) => (
              <tr key={event.eventId}>
                <td>
                  <span>{event.eventCode}</span>
                </td>
                <td>
                  <span>{event.eventName}</span>
                </td>
                <td>
                  <span>{dateFormatter("hi-IN", event.startDate)}</span>
                </td>
                <td>
                  <span>{currencyFormatter("en-US", "USD", event.fees)}</span>
                </td>
                <td>
                  <NavLink
                    to={"/events/" + event.eventId}
                    className="btn btn-dark"
                  >
                    Show Details
                  </NavLink>
                  {/* <button
                    className="btn btn-dark"
                    onClick={() => onEventSelection(event.eventId)}
                  >
                    Show Details
                  </button> */}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {/* {selectedEvent ? <EventDetails event={selectedEvent} /> : ""} */}
      </div>
    );
  } else {
    return (
      <div>
        <h3>Loading...</h3>
      </div>
    );
  }
};
export default EventsList;
