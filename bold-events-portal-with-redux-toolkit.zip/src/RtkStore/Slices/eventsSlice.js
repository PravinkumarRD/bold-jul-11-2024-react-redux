import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  getAllEvents,
  getEventDetails,
} from "../../Events/Services/EventsService";

// Define the initial state
const initialState = {
  events: [],
  event: null,
  status: "idle", // idle | loading | succeeded | failed
  error: null,
};

// Create an async thunk for fetching events
export const fetchEvents = createAsyncThunk(
  "events/fetchEvents",
  async (_, { rejectWithValue }) => {
    try {
      return await getAllEvents();
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
export const fetchEventDetails = createAsyncThunk(
  "events/fetchEventDetails",
  async (eventId,{rejectWithValue}) => {
    try {
      return await getEventDetails(eventId);
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

// Create the events slice
const eventsSlice = createSlice({
  name: "events",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchEvents.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchEvents.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.events = action.payload;
      })
      .addCase(fetchEvents.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchEventDetails.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchEventDetails.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.event = action.payload;
        console.log(action.payload);
      })
      .addCase(fetchEventDetails.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});

export default eventsSlice.reducer;
