import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  getAllEmployees,
  getEmployeeDetails,
} from "../../Employees/services/employees-service";

// Define the initial state
const initialState = {
  employees: [],
  employee: null,
  status: "idle", // idle | loading | succeeded | failed
  error: null,
};

// Create an async thunk for fetching employees
export const fetchAllEmployees = createAsyncThunk(
  "employees/fetchAllEmployees",
  async (_, { rejectWithValue }) => {
    try {
      return await getAllEmployees();
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
export const fetchEmployeeDetails = createAsyncThunk(
  "employees/fetchEmployeeDetails",
  async (employeeId,{rejectWithValue}) => {
    try {
      return await getEmployeeDetails(employeeId);
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

// Create the employees slice
const employeesSlice = createSlice({
  name: "employees",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllEmployees.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchAllEmployees.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.employees = action.payload;
      })
      .addCase(fetchAllEmployees.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchEmployeeDetails.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchEmployeeDetails.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.employee = action.payload;
        console.log(action.payload);
      })
      .addCase(fetchEmployeeDetails.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});

export default employeesSlice.reducer;
