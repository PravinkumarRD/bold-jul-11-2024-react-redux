import { configureStore } from "@reduxjs/toolkit";
import eventsReducer from "./Slices/eventsSlice";
import employeesReducer from "./Slices/employeesSlice";
import logger from "redux-logger";

const store = configureStore({
  reducer: {
    eventsReducer,
    employeesReducer
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(logger),
});

export default store;
