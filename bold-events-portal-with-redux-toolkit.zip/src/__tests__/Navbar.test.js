// Navbar.test.js

import React from 'react';
import { render, screen } from '@testing-library/react';
import { BrowserRouter as Router } from 'react-router-dom';
import '@testing-library/jest-dom';
import { Navbar } from '../Navigation/Components/Navbar';

describe('Navbar', () => {
  it('renders the logo with correct attributes', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const logo = screen.getByAltText('Bold EP');
    expect(logo).toBeInTheDocument();
    expect(logo).toHaveAttribute('src', '../images/bold-logo.png');
    expect(logo).toHaveStyle({ width: '100px', height: '20%' });
  });

  it('renders the Home link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const homeLink = screen.getByText('Home');
    expect(homeLink).toBeInTheDocument();
    expect(homeLink).toHaveClass('nav-link active');
  });

  it('renders the Employees link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const employeesLink = screen.getByText('Employees');
    expect(employeesLink).toBeInTheDocument();
    expect(employeesLink).toHaveClass('nav-link');
  });

  it('renders the Events link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const eventsLink = screen.getByText('Events');
    expect(eventsLink).toBeInTheDocument();
    expect(eventsLink).toHaveClass('nav-link');
  });

  it('renders the Register Event link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const registerEventLink = screen.getByText('Register Event');
    expect(registerEventLink).toBeInTheDocument();
    expect(registerEventLink).toHaveClass('nav-link');
  });

  it('renders the SignUp link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const signUpLink = screen.getByText('SignUp');
    expect(signUpLink).toBeInTheDocument();
    expect(signUpLink).toHaveClass('nav-link');
  });

  it('renders the SignIn link', () => {
    render(
      <Router>
        <Navbar />
      </Router>
    );
    const signInLink = screen.getByText('SignIn');
    expect(signInLink).toBeInTheDocument();
    expect(signInLink).toHaveClass('nav-link');
  });
});
