// BoldHome.test.js

import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import { BoldHome } from '../Home/BoldHome';

describe('BoldHome', () => {
  it('renders the welcome message', () => {
    render(<BoldHome />);
    const welcomeMessage = screen.getByText('Welcome To Bold Events Management Portal!');
    expect(welcomeMessage).toBeInTheDocument();
  });

  it('renders the horizontal rule', () => {
    render(<BoldHome />);
    const hrElement = screen.getByRole('separator');
    expect(hrElement).toBeInTheDocument();
  });

  it('renders the designed and developed message', () => {
    render(<BoldHome />);
    const designedMessage = screen.getByText('Designed and Developed Bold! India Developers!');
    expect(designedMessage).toBeInTheDocument();
  });
});
