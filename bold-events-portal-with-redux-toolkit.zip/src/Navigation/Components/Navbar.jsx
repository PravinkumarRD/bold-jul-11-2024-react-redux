import { NavLink } from "react-router-dom";

export const Navbar = () => {
  let logo = "../images/bold-logo.png";
  return (
    <nav className="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
      <div className="container-fluid">
        <NavLink className="navbar-brand" to={"/"}>
          <img
            src={logo}
            alt="Bold EP"
            style={{ width: "100px", height: "20%" }}
          />
        </NavLink>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarColor02"
          aria-controls="navbarColor02"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarColor02">
          <ul className="navbar-nav me-auto">
            <li className="nav-item">
              <NavLink className="nav-link active" to="/home">
                Home
                <span className="visually-hidden">(current)</span>
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/employees">
                Employees
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink className="nav-link" to="/events">
                Events
              </NavLink>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                Register Event
              </a>
            </li>
            <li className="nav-item">
              <a className="nav-link" href="#">
                SignUp
              </a>
            </li>
            <NavLink className="nav-link" to="/signin">
              SignIn
            </NavLink>
          </ul>
        </div>
      </div>
    </nav>
  );
};
