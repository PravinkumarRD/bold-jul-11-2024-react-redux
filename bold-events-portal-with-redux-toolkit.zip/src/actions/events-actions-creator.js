import {
  FETCH_ALL_EVENTS,
  FETCH_EVENT_DETAILS,
  ERROR_ACTION,
} from "./bold-action-types";

import {
  getAllEvents,
  getEventDetails,
} from "../Events/Services/EventsService";

export const fetchAllEvents = () => async (dispatch) => {
  try {
    const data = await getAllEvents();
    dispatch({
      type: FETCH_ALL_EVENTS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: ERROR_ACTION,
      payload: error,
    });
  }
};
export const fetchEventDetails = (eventId) => async (dispatch) => {
    try {
      const data = await getEventDetails(eventId);
      dispatch({
        type: FETCH_EVENT_DETAILS,
        payload: data,
      });
    } catch (error) {
      dispatch({
        type: ERROR_ACTION,
        payload: error,
      });
    }
  };