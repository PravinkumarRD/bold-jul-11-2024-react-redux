import {
  FETCH_ALL_EMPLOYEES,
  FETCH_EMPLOYEE_DETAILS,
  ERROR_ACTION,
} from "./bold-action-types";

import {
  getAllEmployees,
  getEmployeeDetails,
} from "../Employees/services/employees-service";

export const fetchAllEmployees = () => async (dispatch) => {
  try {
    const data = await getAllEmployees();
    dispatch({
      type: FETCH_ALL_EMPLOYEES,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: ERROR_ACTION,
      payload: error,
    });
  }
};
export const fetchEmployeeDetails = (employeeId) => async (dispatch) => {
  try {
    const data = await getEmployeeDetails(employeeId);
    dispatch({
      type: FETCH_EMPLOYEE_DETAILS,
      payload: data,
    });
  } catch (error) {
    dispatch({
      type: ERROR_ACTION,
      payload: error,
    });
  }
};
