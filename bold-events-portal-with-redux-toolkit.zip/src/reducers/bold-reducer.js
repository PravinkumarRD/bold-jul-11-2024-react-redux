import { combineReducers } from "redux";

import employeesReducer from "./employees-reducer";
import eventsReducer from "./events-reducer";

export default combineReducers({
  eventsReducer,
  employeesReducer,
});
