import {
    FETCH_ALL_EMPLOYEES,
    FETCH_EMPLOYEE_DETAILS,
    ERROR_ACTION,
  } from "../actions/bold-action-types";
  
  const EmployeeStateObject = {
    employees: [],
    employee: null,
    error: null,
  };
  
  export default function employeesReducer(state = EmployeeStateObject, action) {
    switch (action.type) {
      case FETCH_ALL_EMPLOYEES:
        state = {
          ...state,
          employees: action.payload,
        };
        break;
      case FETCH_EMPLOYEE_DETAILS:
        state = {
          ...state,
          employee: action.payload,
        };
        break;
      case ERROR_ACTION:
        state = {
          ...state,
          error: action.payload,
        };
        break;
      default:
        break;
    }
    return state;
  }
  