import {
  FETCH_ALL_EVENTS,
  FETCH_EVENT_DETAILS,
  ERROR_ACTION,
} from "../actions/bold-action-types";

const EventsStateObject = {
  events: [],
  event: null,
  error: null,
};

export default function eventsReducer(state = EventsStateObject, action) {
  switch (action.type) {
    case FETCH_ALL_EVENTS:
      state = {
        ...state,
        events: action.payload,
      };
      break;
    case FETCH_EVENT_DETAILS:
      state = {
        ...state,
        event: action.payload,
      };
      break;
    case ERROR_ACTION:
      state = {
        ...state,
        error: action.payload,
      };
      break;
    default:
      break;
  }
  return state;
}
