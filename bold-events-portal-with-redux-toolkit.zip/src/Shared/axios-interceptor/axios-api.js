import axios from "axios";

const boldAxios = axios.create({
  baseURL: "http://localhost:9090/api",
});

boldAxios.interceptors.request.use((request) => {
  request.headers = {
    "Content-Types": "application/json",
    "bold-authorization-token": localStorage.getItem("token"),
  };
  return request;
});

export default boldAxios;
