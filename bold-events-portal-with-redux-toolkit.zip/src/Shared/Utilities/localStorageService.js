export function getTokenFromLocalStorage(key) {
  const token = localStorage.getItem(key);
  if (token) {
    return true;
  }
  return false;
}
export function getRoleFromLocalStorage(key) {
  return localStorage.getItem(key);
}
