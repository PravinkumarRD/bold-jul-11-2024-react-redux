// dateFormatter.test.js

import { dateFormatter } from './Globalization';

describe('dateFormatter', () => {
  it('should format the current date and time in the default locale "en-IN"', () => {
    const now = new Date();
    const formattedDate = dateFormatter();
    const expectedDate = new Intl.DateTimeFormat('en-IN', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(now);

    expect(formattedDate).toBe(expectedDate);
  });

  it('should format a specific date and time in the "en-US" locale', () => {
    const specificDate = new Date();
    const formattedDate = dateFormatter('en-US', specificDate);
    const expectedDate = new Intl.DateTimeFormat('en-US', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(specificDate);

    expect(formattedDate).toBe(expectedDate);
  });
});
