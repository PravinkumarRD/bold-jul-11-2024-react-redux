// currencyFormatter.test.js

import { currencyFormatter } from "./Globalization";

describe("currencyFormatter", () => {
  it('should format 0 in the default locale "en-IN" and currency "INR"', () => {
    const formattedCurrency = currencyFormatter();
    const expectedCurrency = new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(100);

    expect(formattedCurrency).toBe(expectedCurrency);
  });

  it('should format 1234.56 in "en-US" locale and "USD" currency', () => {
    const formattedCurrency = currencyFormatter("en-US", "USD", 1234.56);
    const expectedCurrency = new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(1234.56);

    expect(formattedCurrency).toBe(expectedCurrency);
  });

  it('should format 987654.32 in "ja-JP" locale and "JPY" currency', () => {
    const formattedCurrency = currencyFormatter("ja-JP", "JPY", 987654.32);
    const expectedCurrency = new Intl.NumberFormat("ja-JP", {
      style: "currency",
      currency: "JPY",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(987654.32);

    expect(formattedCurrency).toBe(expectedCurrency);
  });

  it("should handle negative values correctly", () => {
    const formattedCurrency = currencyFormatter("en-IN", "INR", -5000.75);
    const expectedCurrency = new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(-5000.75);

    expect(formattedCurrency).toBe(expectedCurrency);
  });

  it("should format large numbers correctly", () => {
    const formattedCurrency = currencyFormatter("en-IN", "INR", 1234567890.12);
    const expectedCurrency = new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(1234567890.12);

    expect(formattedCurrency).toBe(expectedCurrency);
  });
});
