import axios from "axios";

const BoldAxios = axios.create();

BoldAxios.interceptors.request.use((request) => {
  const noInterceptorUrl = request.url.includes("authenticate");
  request.baseURL = "http://localhost:9090/api";
  if (!noInterceptorUrl) {
    request.headers = {
      "Content-Types": "application/json",
      "Bold-Developer-Name": "Alisha C.",
      "bold-authorization-token": `${localStorage.getItem("token")}`,
    };
  }
  return request;
});

export default BoldAxios;
