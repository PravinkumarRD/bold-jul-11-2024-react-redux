// import styles from "./App.module.css";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";

import BoldStore from "./Store/BoldStore";

import { MainLayout } from "./MainLayout";

function App() {
  return (
    <Provider store={BoldStore}>
      <BrowserRouter>
        <MainLayout />
      </BrowserRouter>
    </Provider>
  );
}

export default App;
