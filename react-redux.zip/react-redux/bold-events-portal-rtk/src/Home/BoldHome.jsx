import React from 'react'

export const BoldHome = () => {
  return (
    <>
        <h1>Welcome To Bold Events Portal! India!</h1>
        <hr />
        <h6>Designed and Developed by BOLD Employees!</h6>
    </>
  )
}
