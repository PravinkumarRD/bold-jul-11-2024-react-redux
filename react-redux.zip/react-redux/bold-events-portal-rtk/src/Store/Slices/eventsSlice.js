//Initial State Object for that feature
//For Example -
/*
    const state={
        events:[],
        event:null
        newEvent:null,
        status:'idle'
    }
*/
//ActionCreaters - Methods For Example - Nextwork calls

//Reducer - The function which will update the state in the store

import { createSlice, createAsyncThunk, createAction } from "@reduxjs/toolkit";
import {
  getAllEvents,
  getEventDetails,
} from "../../Events/Services/EventsService";

const initialState = {
  events: [],
  event: null,
  newEvent: null,
  status: "idle",
};
//Action Creaters

export const updateStatus=createAction("UpdateStatus",()=>{

});

export const fetchEvents = createAsyncThunk(
  "events/fetchEvents",
  async (_, { rejectWithValue }) => {
    try {
      return await getAllEvents();
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);
export const fetchEventDetails = createAsyncThunk(
  "events/fetchEventDetails",
  async (eventId, { rejectWithValue }) => {
    try {
      return await getEventDetails(eventId);
    } catch (error) {
      return rejectWithValue(error);
    }
  }
);

const eventsSlice = createSlice({
  name: "events",
  initialState,
  reducers: {
    setStatusToIdle(state) {
      state.status = 'success';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchEvents.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchEvents.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.events = action.payload;
      })
      .addCase(fetchEvents.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      })
      .addCase(fetchEventDetails.pending, (state) => {
        state.status = "loading";
      })
      .addCase(fetchEventDetails.fulfilled, (state, action) => {
        state.status = "succeeded";
        state.event = action.payload;
        console.log(action.payload);
      })
      .addCase(fetchEventDetails.rejected, (state, action) => {
        state.status = "failed";
        state.error = action.error.message;
      });
  },
});

export default eventsSlice.reducer;
