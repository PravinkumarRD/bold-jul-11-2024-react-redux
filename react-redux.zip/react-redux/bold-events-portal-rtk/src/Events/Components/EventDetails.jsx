import { useEffect } from "react";
import { useParams } from "react-router-dom";

import { useDispatch, useSelector } from "react-redux";
import { fetchEventDetails } from "../../Store/Slices/eventsSlice";

const EventDetails = () => {
  let title = "Details Of - ";
  const params = useParams();
  const dispatch = useDispatch();
  const event = useSelector((state) => state.eventsReducer.event);
  const status = useSelector((state) => state.eventsReducer.status);
  // const error = useSelector((state) => state.eventsReducer.error);
  useEffect(() => {
    dispatch(fetchEventDetails(params.id));
  }, [params, dispatch]);

  if (event) {
    return (
      <div>
        <h1>{title + event.eventName}</h1>
        <table className="table table-hover table-striped">
          <tbody>
            <tr>
              <th>Event Id</th>
              <td>
                <span>{event.eventId}</span>
              </td>
            </tr>
            <tr>
              <th>Event Code</th>
              <td>
                <span>{event.eventCode}</span>
              </td>
            </tr>
            <tr>
              <th>Event Name</th>
              <td>
                <span>{event.eventName}</span>
              </td>
            </tr>
            <tr>
              <th>Event Logo</th>
              <td>
                <img src={"../" + event.logo} alt={event.eventName} />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  } else {
    return <h3>Loading...</h3>;
  }
};

export default EventDetails;
